
#include <stdio.h>
#include<stdlib.h>
#include<string.h>


int main(int arg, char **argc)
{
        if(arg!=2)
        {
                printf("input format: a.out  filemane\n");
                exit(0);
        }


   char s[100],(*p)[100]=NULL;
    int i=0,f,l;
    FILE *fp=fopen(argc[1],"r");


    if(fp==NULL)
    {
        perror("fopen");
        exit(0);
    }

    else
    {
        while(fgets(s,100,fp))
        {
          p=realloc(p,100);
          strcpy(p[i++],s);
        }


    for(f=0,l=i-1;f<l;f++,l--)
    {
      printf("%s%s",p[f],p[l]);
    }


    if(i%2==1)
    printf("%s",p[f]);


    }

    free(p);
    fclose(fp);


}